﻿let initCoreHelpers = function(){
    let widgetsList = document.querySelector('head > captcha-widgets');
    if(!widgetsList){
        widgetsList = document.createElement("captcha-widgets");
        document.head.appendChild(widgetsList);
    }
    window._mbRegisterCaptchaWidget = function(widgetInfo){
        let widget = document.createElement("captcha-widget");
        for(let k in widgetInfo){
            widget.dataset[k] = widgetInfo[k];
        }
        widgetsList.appendChild(widget);
    };
    window._mbIsCaptchaWidgetRegistered = function(captchaType, widgetId){
        let widgets = widgetsList.children;
        for(let i = 0; i < widgets.length; i++){
            if(widgets[i].dataset.captchaType !== captchaType){continue;}
            if(widgets[i].dataset.widgetId !== widgetId + ''){continue;}
            return true;
        }
        return false;
    };
    window._mbResetCaptchaWidget = function(captchaType, widgetId){
        let widgets = widgetsList.children;
        for(let i = 0; i < widgets.length; i++){
            let wd = widgets[i].dataset;
            if(wd.captchaType != captchaType){continue;}
            if(wd.widgetId != widgetId){continue;}
            wd.reset = true; break;
        }
    };
	window._mbDelCaptchaWidget = function(){
		document.querySelector('head > captcha-widgets').innerHTML = "";
	};
    window._mbGetCaptchaWidgetButton = function(captchaType, widgetId){
        return document.querySelector(`.captcha-solver[data-captcha-type="${captchaType}"][data-widget-id="${widgetId}"]`);
    };
};
setTimeout(initCoreHelpers, 200);