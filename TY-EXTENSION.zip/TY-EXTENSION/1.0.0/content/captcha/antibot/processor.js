﻿CaptchaProcessors.register({
    captchaType: "antibot",
    canBeProcessed: function(widget, config){
        if(!config.solveAntiBot){return false;}
        if(!$(`#${widget.containerId}`).length){return false;}
        return true;
    },
    attachButton: function(widget, config, button){
        let container = $(`#${widget.containerId}`);
        button.css({
            width: container.find('iframe').outerWidth() + "px"
        });
		container.append(button);
        if(config.solveAntiBot){
			button.click();
		}
    },
    clickButton: function(widget, config, button){
        if(config.solveAntiBot){
			button.click();
		}
    },
    getParams: function(widget, config){
        var new_widget = {};
        for(key in widget){
			if (/^\d+$/.test(key) || key==='main'){
				new_widget[key]=widget[key]
			}
        }
        return new_widget;
    },
    onSolved: function(widget, answer){
		for(var key of answer.split(',')){
			document.querySelector(`[rel="${key}"] img`).click();
		}
        var rels = ' ';
        rels += answer.replace(/,/g, ' ');
        $('input#antibotlinks').val(rels);
    },
    getForm: function(widget){
        return false;
    },
    getCallback: function(widget){
        return null;
    },
});