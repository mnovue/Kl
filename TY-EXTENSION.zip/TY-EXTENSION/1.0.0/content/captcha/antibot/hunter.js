﻿(() => {
	async function getBase64FromImage(img) {
		return new Promise((resolve, reject) => {
			const canvas = document.createElement('canvas');
			const ctx = canvas.getContext('2d');
			canvas.width = img.naturalWidth;
			canvas.height = img.naturalHeight;
			ctx.drawImage(img, 0, 0);
			resolve(canvas.toDataURL('image/png'));
		});
	}

	setInterval(async () => {
		const antibotContainer = document.querySelector("a#antibotlinks_reset") || document.querySelector(".antibot-instruction");
		if (!antibotContainer) return;

		if(antibotContainer?.style?.display == "none"){
			antibotContainer.style.display = "block";
		}
        if (!window._mbRegisterCaptchaWidget || _mbIsCaptchaWidgetRegistered("antibot", 0)) return;

		let obj_links = {};

		try {
			const mainImg = antibotContainer.querySelector('img[src*="blob:"]');
			const container = antibotContainer;
			if (mainImg) {
				obj_links['main'] = await getBase64FromImage(mainImg);

				const blobLinks = document.querySelectorAll('.atblink');
				for (let i = 0; i < blobLinks.length; i++) {
					const rel = `1${i}1`;
					blobLinks[i].setAttribute('rel', rel);

					const img = blobLinks[i].querySelector('img');
					if (img) {
						obj_links[rel] = await getBase64FromImage(img);
					}
				}
			}
			else {
				const dataImg = antibotContainer.parentNode.querySelector('img[src^="data:image/"]');
				const container = antibotContainer.parentNode;
				if (dataImg) {
					obj_links['main'] = dataImg.src;

					const links = document.querySelectorAll('a');
					for (const link of links) {
						if (link.rel && !isNaN(link.rel)) {
							const img = link.querySelector('img');
							if (img) {
								obj_links[link.rel] = img.src;
							} else if (link.innerText.includes('Anti-Bot')) {
								obj_links[link.rel] = link.innerText.replace('Anti-Bot ( ', '').replace(' )', '');
							}
						}
					}
				}
			}

			if (Object.keys(obj_links).length < 3) return;

			if (!container.id) {
				container.id = "antibot-container-" + Date.now();
			}
			obj_links['captchaType'] = 'antibot';
			obj_links['widgetId'] = 0;
			obj_links['containerId'] = container.id;
			obj_links['callback'] = null;
            _mbRegisterCaptchaWidget(obj_links);
		} catch (error) {}
	}, 2000);
})();