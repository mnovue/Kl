CaptchaProcessors.register({
    captchaType: "captchafox",
    canBeProcessed: function(widget, config){
        if(!config.solveCaptchaFox){return false;}
		if(!widget.sitekey){return false;}
        return true;
    },
    attachButton: function(widget, config, button){
        let helper = this.getHelper(widget);
        if (helper.find('.captcha-solver').length !== 0){
            return;
        }
        button.css({
            width: helper.outerWidth() + "px"
        });
        button[0].dataset.disposable = true;
        helper.append(button);
        if(config.solveCaptchaFox){
			button.click();
		}
    },
    getParams: function(widget, config){
        return {
            method: "captchafox",
            url: location.href,
            sitekey: widget.sitekey,
            pageurl: widget.pageurl,
        };
    },
	onSolved: function(widget, answer){
        let helper = this.getHelper(widget);
        this.setValueInput(helper, '[name="cf-captcha-response"]', answer);
		$(`<div class="mb-captchafox-helper"><input type="hidden" name="token"></div>`).appendTo(helper);
		document.querySelector(".mb-captchafox-helper input").value = answer;
		let injScript = document.createElement('script');
		injScript.src = chrome.runtime.getURL("content/captcha/captchafox/validate.js");
		document.body.append(injScript);
    },
    setValueInput(helper, name, answer){
        const input = helper.find(name);
        if(input && input.length){
            input.val(answer);
        }
    },
    getForm: function(widget){
        return this.getHelper(widget).closest("form");
    },
    getCallback: function(widget){
        return null;
    },
    getHelper: function(widget){
        let container = $(`#${widget.inputId}`);
        return container.parent();
    },
});