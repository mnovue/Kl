if (typeof window.captchafoxCallback === "function"){
	window.captchafoxCallback(document.querySelector(".mb-captchafox-helper input").value);
}