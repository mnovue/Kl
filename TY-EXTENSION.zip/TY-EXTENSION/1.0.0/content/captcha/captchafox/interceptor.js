(() => {
    const waitFor = (fnName, callback, timeout = 10000, interval = 50) => {
        const start = Date.now();
        const timer = setInterval(() => {
            if (typeof window[fnName] === "function") {
                clearInterval(timer);
                callback();
            } else if (Date.now() - start > timeout) {
                clearInterval(timer);
            }
        }, interval);
    };

    const interceptorFunc = (captchafox) => {
        const initCaptcha = ([div, params]) => {
            const doInit = () => {
                try {
                    const input = div.parentElement;
                    if (!input.id || input.id.startsWith('captchafox-input-')) {
                        try { _mbDelCaptchaWidget(); } catch (e) { console.error(e); }
                        try {
                            if (input.id.startsWith('captchafox-input-')) {
                                const button = _mbGetCaptchaWidgetButton('captchafox', input.id);
                                if (button) button.remove();
                            }
                        } catch (e) { console.error(e); }

                        if (div.id) {
                            input.id = "captchafox-input-" + div.id;
                        } else {
                            input.id = "captchafox-input-" + (params?.sitekey || 'unknown');
                        }
                    }

                    const inputId = input.id;

                    if (params?.callback) {
                        window.captchafoxCallback = params.callback;
                    }
                    if (params?.onVerify) {
                        window.captchafoxCallback = params.onVerify;
                    }

                    _mbRegisterCaptchaWidget({
                        captchaType: "captchafox",
                        widgetId: inputId,
                        sitekey: params?.sitekey,
                        pageurl: window.location.href,
                        inputId: inputId
                    });
                } catch (e) {
                    console.error('[initCaptcha] Ошибка:', e);
                }
            };
            if (typeof window._mbRegisterCaptchaWidget !== "function") {
                waitFor('_mbRegisterCaptchaWidget', doInit, 10000, 50);
            } else {
                doInit();
            }
        };

        if (!captchafox._originalRender) {
            captchafox._originalRender = captchafox.render;
            captchafox.render = function (...args) {
                try {
                    initCaptcha(args);
                } catch (err) {
                    console.error('Ошибка в initCaptcha:', err);
                }
                return captchafox._originalRender.apply(this, args);
            };
        }

        if (!captchafox._originalGetResponse) {
            captchafox._originalGetResponse = captchafox.getResponse;
            captchafox.getResponse = function (...args) {
                const val = document.querySelector('[name="cf-captchafox-response"]')?.value || document.querySelector('[name="cf-captcha-response"]')?.value;
                return val || captchafox._originalGetResponse.apply(this, args);
            };
        }
    };

    if (window.captchafox) {
        interceptorFunc(window.captchafox);
    } else {
        Object.defineProperty(window, "captchafox", {
            configurable: true,
            enumerable: true,
            set(value) {
                delete window.captchafox;
                window.captchafox = value;
                interceptorFunc(value);
            },
            get() {
                return undefined;
            }
        });
    }
})();
