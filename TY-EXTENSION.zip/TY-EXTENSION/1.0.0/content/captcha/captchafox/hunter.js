(() => {
    setInterval(function (){
        let cf = document.querySelector("#captchafox") || document.querySelector(".captchafox");
        if(!cf){
            const inputResponse = document.querySelector('[name*="cf-captcha-"]');
            cf = inputResponse && inputResponse.parentNode;
        }
        if(!cf){return;}
        getcaptchafoxWidgetInfo(cf);
    }, 3000);
    
    const getcaptchafoxData = function(cf){
        if(!cf) return null;
        const sitekey = cf.getAttribute('data-sitekey') || cf.parentNode?.getAttribute('data-sitekey');
        const callback = cf.getAttribute('data-callback') || cf.parentNode?.getAttribute('data-callback');
        
        return {
            sitekey,
            callback
        };
    };
    
    const getcaptchafoxWidgetInfo = function(cf){
        const data = getcaptchafoxData(cf);
        if(data && data.sitekey){
            if(!cf.id){
                cf.id = "captchafox-input-" + data.sitekey;
            }
            if(_mbIsCaptchaWidgetRegistered("captchafox", cf.id)){return;}
            const widgetData = {
                captchaType: "captchafox",
                widgetId: cf.id,
                sitekey: data.sitekey,
                inputId: cf.id,
            };
            if(data.callback) {
                widgetData.callback = data.callback;
            }
            _mbRegisterCaptchaWidget(widgetData);
        }
    };
})();