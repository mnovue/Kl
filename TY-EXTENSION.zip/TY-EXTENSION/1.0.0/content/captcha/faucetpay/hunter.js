﻿function isVisible(sel){
	var e = document.querySelector(sel);
	return !! e && ( e.offsetWidth || e.offsetHeight || e.getClientRects().length );
}
function info_img(sel){
	var info = false,
	img = document.querySelector(sel),
	style = img.currentStyle || window.getComputedStyle(img, false),
	info = style.backgroundImage.slice(4, -1).replace(/"/g, "");
	return info;
}
function isCanvasReady(canvas){
	try{
		var context = canvas.getContext('2d', { willReadFrequently: true });
		var pixelBuffer = new Uint32Array(
		context.getImageData(0, 0, canvas.width, canvas.height).data.buffer
		);
		return pixelBuffer.some(color => color !== 0);
	}catch(e){
		return false;
	}
}
(() => {
    setInterval(async function (){
        if(window._mbRegisterCaptchaWidget){
			if(window.BasiliskCaptcha === undefined){return;}
            if(!_mbIsCaptchaWidgetRegistered("slider", 0)){
				var background = false,
				piece = false;
				if(isVisible('[class*="styles_captcha__"] div div div')){
					document.querySelector('[class*="styles_captcha__"] div div div').click();
				}
				if(isVisible('canvas')){
					if(document.querySelectorAll("canvas").length == 2){
						if(isCanvasReady(document.querySelectorAll("canvas")[0])){
							if(isCanvasReady(document.querySelectorAll("canvas")[1])){
								background = document.querySelectorAll("canvas")[0].toDataURL("image/png");
								piece = document.querySelectorAll("canvas")[1].toDataURL("image/png");
							}
						}
					}
				}
                if(background && piece){
                    _mbDelCaptchaWidget();
					var container = document.querySelector('[style*="position: absolute; top: 50%; left: 50%;"]').parentNode;
					container.id = "slider-container-" + Date.now();
            _mbRegisterCaptchaWidget({
						captchaType: "slider",
						widgetId: 0,
						background: background,
						piece: piece,
						containerId: container.id,
						callback: null,
					});
				}
			}
            if(!_mbIsCaptchaWidgetRegistered("icons", 0)){
				var body = false,
				task = [],
				icons = {
					"-141px": "calendar",
					"-115px": "calendar",
					"-91px": "buy",
					"-67px": "buy",
					"-21px": "star",
					"-44px": "star"
				};
				if(isVisible('[style*="/challenges/icons/"]')){
					const toDataURL = url => fetch(url)
						.then(response => response.blob())
						.then(blob => new Promise((resolve, reject) => {
							const reader = new FileReader()
							reader.onloadend = () => resolve(reader.result)
							reader.onerror = reject
							reader.readAsDataURL(blob)
						}));
					body = await toDataURL(info_img('[style*="/challenges/icons/"]'));
					var icons_sel = document.querySelectorAll('div[style="display: flex;"] div'),
					tasks = [];
					for(var key of icons_sel){
						if(key.style["background-position-y"] in icons){
							tasks.push(icons[key.style["background-position-y"]]);
						}
					}
					task = tasks.join(',')
				}
                if(body && task){
                    _mbDelCaptchaWidget();
					var container = document.querySelector('[style*="position: absolute; top: 50%; left: 50%;"]').parentNode;
					container.id = "icons-container-" + Date.now();
            _mbRegisterCaptchaWidget({
						captchaType: "icons",
						widgetId: 0,
						body: body,
						task: task,
						containerId: container.id,
						callback: null,
					});
				}
			}
        }
    }, 5000);
})()