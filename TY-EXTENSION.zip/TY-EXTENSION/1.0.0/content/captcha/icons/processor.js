﻿CaptchaProcessors.register({
    captchaType: "icons",
    canBeProcessed: function(widget, config){
        if(!config.solveFaucetPay){return false;}
        if(!$(`#${widget.containerId}`).length){return false;}
        return true;
    },
    attachButton: function(widget, config, button){
        let container = $(`#${widget.containerId}`);
        button.css({
            width: container.find('iframe').outerWidth() + "px"
        });
		container.append(button);
        if(config.solveFaucetPay){
			button.click();
		}
    },
    getParams: function(widget, config){
        return {
            body: widget.body,
            task: widget.task
        };
    },
    onSolved: function(widget, answer){
		const timer = ms => new Promise(res => setTimeout(res, ms))
		function getOffset(el) {
			const rect = el.getBoundingClientRect();
				return {
					left: rect.left + window.scrollX,
					top: rect.top + window.scrollY
			};
		}
		function _Event(type, clientX, clientY){
			let evt = new MouseEvent(type, {
				isTrusted: true,
				clientX: clientX,
				clientY: clientY,
				bubbles: true,
				cancelable: true,
				view: window

			});
			return evt;
		}
		function _Pointer(type, clientX, clientY){
			let evt = new PointerEvent(type, {
				isTrusted: true,
				clientX: clientX,
				clientY: clientY,
				bubbles: true,
				cancelable: true,
				view: window

			});
			return evt;
		}
		function _Interval(min=1, max=10){
		  return Math.floor(Math.random() * (max - min + 1) + min)
		}
		var canvas_icons = document.querySelector('canvas');
		var offset = getOffset(canvas_icons);
		canvas_icons.focus();
		async function move(){
			var start_x = offset.left;
			var start_y = offset.top;
			for(var key of answer.split(',')){
				var x = + Number(key.split(':')[0]) + offset.left,
				y = + Number(key.split(':')[1]) + offset.top;
				while(start_x != x || start_y != y){
					if(x > start_x){
						start_x += _Interval();
						if(start_x > x){
							start_x = x;
						}
					}
					if(x < start_x){
						start_x -= _Interval();
						if(start_x < x){
							start_x = x;
						}
					}
					if(y > start_y){
						start_y += _Interval();
						if(start_y > y){
							start_y = y;
						}
					}
					if(y < start_y){
						start_y -= _Interval();
						if(start_y < y){
							start_y = y;
						}
					}
					canvas_icons.dispatchEvent(_Event("mousemove", start_x, start_y));
					await timer(_Interval(min=10, max=40));
				}
				canvas_icons.dispatchEvent(_Event("mousedown", x, y));
				canvas_icons.dispatchEvent(_Event("mouseup", x, y));
				canvas_icons.dispatchEvent(_Pointer("click", x, y));
			}
			if($('button:contains("Apply")')){
				$('button:contains("Apply")').click();
			}
		}
		move();
    },
    getForm: function(widget){
        return false;
    },
    getCallback: function(widget){
        return null;
    },
});