﻿(() => {
    let timer = setInterval(() => {
        if(window.turnstile){
            interceptorFunc();
            clearInterval(timer);
        }
    }, 1)
    const interceptorFunc = function(){
        const initCaptcha = ([div, params]) => {
			try {
				const input = div.parentElement;

				if (!input.id || input.id.startsWith('turnstile-input-')) {
					try{ _mbDelCaptchaWidget(); }catch(e){ console.error(e); }
					try{
						if(input.id.startsWith('turnstile-input-')){
							const button = _mbGetCaptchaWidgetButton('turnstile', input.id);
							if(button){button.remove();}
						}
					}catch(e){console.error(e);}
					if (div.id) {
						input.id = "turnstile-input-" + div.id;
					} else {
						input.id = "turnstile-input-" + params.sitekey;
					}
				}

				inputId = input.id;
			} catch (e) {
				inputId = div.replace("#", "");
			}
			if (params.callback) {
				window.turnstileCallback = params.callback;
			}
            _mbRegisterCaptchaWidget({
                captchaType: "turnstile",
                widgetId: inputId,
                sitekey: params.sitekey,
                pageurl: window.location.href,
                data: params.cData || null,
                pagedata: params.chlPageData || null,
                action: params.action || null,
                inputId: inputId
            });
        }
        window.turnstile = new Proxy(window.turnstile,{
            get: function (target, prop) {
                if(prop === 'render'){
                    return new Proxy(target[prop], {
                        apply: (target, thisArg, argumentsList) => {
                            initCaptcha(argumentsList);
                            const obj = Reflect.apply(target, thisArg, argumentsList);
                            return obj;
                        }
                    });
                }
				if(prop === 'getResponse'){
                    return new Proxy(target[prop], {
                        apply: (target) => {
                            return document.querySelector('[name="cf-turnstile-response"]').value;
                        }
                    });
				}
                return target[prop];
            }
        });
    }
})()