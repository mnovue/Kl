if (typeof window.turnstileCallback === "function"){
	window.turnstileCallback(document.querySelector(".mb-turnstile-helper input").value);
}