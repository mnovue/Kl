(() => {
    setInterval(function (){
        let cf = document.querySelector("#cf-turnstile") || document.querySelector(".cf-turnstile");
        if(!cf){
            const inputResponse = document.querySelector('input[name*="cf-"]');
            cf = inputResponse && inputResponse.parentNode;
        }
        if(!cf){return;}
        getTurnstileWidgetInfo(cf);
    }, 1000);
    const getTurnstileData = function(cf){
        if(!cf) return null;
        const sitekey = cf.getAttribute('data-sitekey') || cf.parentNode?.getAttribute('data-sitekey');
        const action = cf.getAttribute('data-action') || cf.parentNode?.getAttribute('data-action');
        const cdata = cf.getAttribute('data-cdata') || cf.parentNode?.getAttribute('data-cdata');
        const callback = cf.getAttribute('data-callback') || cf.parentNode?.getAttribute('data-callback');
        
        return {
            sitekey,
			action,
			cdata,
            callback
        };
    };
    const getTurnstileWidgetInfo = function(cf){
        const data = getTurnstileData(cf);
		if(data && data.sitekey){
            if(!cf.id){
                cf.id = "turnstile-input-" + data.sitekey;
            }
			if(_mbIsCaptchaWidgetRegistered("turnstile", cf.id)){return;}
			_mbRegisterCaptchaWidget({
				captchaType: "turnstile",
				widgetId: cf.id,
				sitekey: data.sitekey,
				action: data.action,
				data: data.cdata,
				callback: data.callback,
				inputId: cf.id,
			});
		}
    };
})()