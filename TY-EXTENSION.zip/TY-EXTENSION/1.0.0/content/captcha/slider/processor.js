﻿CaptchaProcessors.register({
    captchaType: "slider",
    canBeProcessed: function(widget, config){
		console.log("slider",!$(`#${widget.containerId}`).length)
        if(!config.solveFaucetPay){return false;}
        if(!$(`#${widget.containerId}`).length){return false;}
        return true;
    },
    attachButton: function(widget, config, button){
        let container = $(`#${widget.containerId}`);
        button.css({
            width: container.find('iframe').outerWidth() + "px"
        });
		container.append(button);
        if(config.solveFaucetPay){
			button.click();
		}
    },
    getParams: function(widget, config){
        return {
            background: widget.background,
            piece: widget.piece
        };
    },
    onSolved: function(widget, answer){
		const timer = ms => new Promise(res => setTimeout(res, ms))
		function _Event(type, clientX){
			let evt = new MouseEvent(type, {
				clientX: clientX,
				clientY: 0,
				bubbles: true,
				cancelable: true,
				view: window

			});
			return evt;
		}
		function _Interval(min=5, max=20){
		  return Math.floor(Math.random() * (max - min + 1) + min)
		}
		let slider = document.querySelector('[style*="rgb(0, 158, 251);"]'),
		clientX = Number(answer);
		slider.focus();
		slider.dispatchEvent(_Event("mousedown", 0));
		async function move(){
			var ev = 1;
			while(ev != clientX){
				ev += 3;
				if(ev > clientX){
					ev = clientX;
				}
				slider.dispatchEvent(_Event("mousemove", ev));
				await timer(_Interval());
			}
			moveup();
		}
		function moveup(){
			slider.dispatchEvent(_Event("mouseup", clientX));
		}
		move();
    },
    getForm: function(widget){
        return false;
    },
    getCallback: function(widget){
        return null;
    },
});