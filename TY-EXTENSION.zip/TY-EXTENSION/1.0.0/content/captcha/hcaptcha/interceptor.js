﻿(() => {
    let hCaptchaInstance;
    let nextWidgetId = 0;
	
    function createHCaptchaWidget(container, opts) {
        if (typeof container !== 'string') {
            if (!container.id) {
                container.id = "hcaptcha-container-" + Date.now();
            }
            container = container.id;
        }
        if (opts.callback !== undefined && typeof opts.callback === "function") {
            let key = "hcaptchaCallback" + Date.now();
            window[key] = opts.callback;
            opts.callback = key;
        }
        let widgetInfo = {
            captchaType: "hcaptcha",
            widgetId: nextWidgetId++,
            containerId: container,
            sitekey: opts.sitekey,
            callback: opts.callback,
        };

        let iter = 0;
        const intId = setInterval(() => {
            if (++iter > 200) {
                clearInterval(intId);
            }
            if (window._mbRegisterCaptchaWidget) {
                clearInterval(intId);
                _mbRegisterCaptchaWidget(widgetInfo);
            }
        }, 500);
    }
	
	Object.defineProperty(window, 'hcaptcha', {
		configurable: true,
		enumerable: true,
		get() {
			return hCaptchaInstance;
		},
		set(value) {
			hCaptchaInstance = value;

			if (hCaptchaInstance && typeof hCaptchaInstance.render === 'function') {
				const originalRender = hCaptchaInstance.render;
				hCaptchaInstance.render = function (container, opts) {
					createHCaptchaWidget(container, opts);
					return originalRender.call(this, container, opts);
				};
			}

			hCaptchaInstance.getResponse = () => document.querySelector('[name=h-captcha-response]').value;
			if (window.grecaptcha) {
				grecaptcha.getResponse = () => document.querySelector('[name=h-captcha-response]').value;
			}
		},
	});
})()