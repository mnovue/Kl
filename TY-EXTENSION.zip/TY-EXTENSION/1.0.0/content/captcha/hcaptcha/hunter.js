﻿(() => {
    function createHCaptchaWidget(container, opts) {
        if (typeof container !== 'string') {
            if (!container.id) {
                container.id = "hcaptcha-container-" + Date.now();
            }
            container = container.id;
        }
        if (opts.callback !== undefined && typeof opts.callback === "function") {
            let key = "hcaptchaCallback" + Date.now();
            window[key] = opts.callback;
            opts.callback = key;
        }
        let widgetInfo = {
            captchaType: "hcaptcha",
            widgetId: 0,
            containerId: container,
            sitekey: opts.sitekey,
            callback: opts.callback,
        };

        let iter = 0;
        const intId = setInterval(() => {
            if (++iter > 200) {
                clearInterval(intId);
            }
            if (window._mbRegisterCaptchaWidget) {
                clearInterval(intId);
                _mbRegisterCaptchaWidget(widgetInfo);
            }
        }, 500);
    }
    function parseScripts() {
        function parseHCaptchaRender(scriptText) {
            const renderPattern = /hcaptcha\.render\s*\(\s*(["'])(.*?)\1\s*,\s*({[\s\S]*?})\s*\)/;
            const match = scriptText.match(renderPattern);

            if (match) {
                const container = match[2];
                const options = match[3];

                const sitekeyMatch = options.match(/(["'])sitekey\1\s*:\s*(["'])(.*?)\2/);
                const callbackMatch = options.match(/(["'])callback\1\s*:\s*([^,}\s]+)/);

                const sitekey = sitekeyMatch ? sitekeyMatch[3] : null;
                const callbackName = callbackMatch ? callbackMatch[2] : null;

                const callback = callbackName && typeof window[callbackName] === 'function'
                    ? window[callbackName]
                    : undefined;

                return {
                    container,
                    sitekey,
                    callback,
                };
            }

            return null;
        }

        const scripts = document.querySelectorAll('script');
        scripts.forEach(script => {
            const scriptText = script.textContent;

            const renderData = parseHCaptchaRender(scriptText);
            if (renderData) {
                console.log('Найден вызов hcaptcha.render:', renderData);

                createHCaptchaWidget(renderData.container, {
                    sitekey: renderData.sitekey,
                    callback: renderData.callback,
                });
            }
        });
    }
    setInterval(function (){
        if(window._mbRegisterCaptchaWidget){
			if(_mbIsCaptchaWidgetRegistered("hcaptcha", 0)){return;}
			let textarea = document.querySelector("textarea[name*=h-captcha-]");
			if(!textarea){return;}
			let container = textarea.parentNode;
			if(!container.id){
				container.id = "hcaptcha-container-" + Date.now();
			}
			if(container.dataset.sitekey){
				_mbRegisterCaptchaWidget({
					captchaType: "hcaptcha",
					widgetId: 0,
					containerId: container.id,
					sitekey: container.dataset.sitekey,
					callback: container.dataset.callback || null,
				});
			}
			else{
				parseScripts();
			}
        }
    }, 3000);

})()