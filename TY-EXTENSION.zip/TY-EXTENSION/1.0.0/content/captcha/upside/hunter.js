﻿function isVisible(sel){
	var e = document.querySelector(sel);
	return !! e && ( e.offsetWidth || e.offsetHeight || e.getClientRects().length );
}
(() => {
    setInterval(async function(){
        if (window._mbRegisterCaptchaWidget){
            if(_mbIsCaptchaWidgetRegistered("upside", 0)) {return;}
			if(isVisible('.check-box')){
				document.querySelector('.check-box').click();
			}
			const checkbox = document.getElementById('captcha-checkbox');
			if (checkbox && !checkbox.checked) {
				checkbox.click();
			}
			
			const captchaImage = document.querySelector('img#captchaImage') || 
								document.querySelector('img.captcha-image') || 
								document.querySelector('.captcha-show img') ||
								document.querySelector('#rscaptcha_img');
			
			const body = captchaImage?.src;
			if(body){
				const container = captchaImage.parentNode?.parentNode || captchaImage.parentNode;
				if(!container.id){
					container.id = "upside-container-" + Date.now();
				}
                _mbRegisterCaptchaWidget({
					captchaType: "upside",
					widgetId: 0,
					body: body,
					containerId: container.id,
					callback: null,
				});
			}
        }
    }, 2000);
})()