﻿CaptchaProcessors.register({
    captchaType: "upside",
    canBeProcessed: function(widget, config){
        if(!config.solveUpside){return false;}
        if(!$(`#${widget.containerId}`).length){return false;}
        return true;
    },
    attachButton: function(widget, config, button) {
        let container = $(`#${widget.containerId}`);
        button.css({
            width: container.find('iframe').outerWidth() + "px"
        });
		container.append(button);
        if(config.solveUpside){
			button.click();
		}
    },
    getParams: function(widget, config){
        return {
            body: widget.body
        };
    },
    onSolved: function(widget, answer){
		function getOffset(el) {
			const rect = el.getBoundingClientRect();
			return {
				left: rect.left,
				top: rect.top
			};
		}
		function _Event(type, clientX, clientY){
			let evt = new MouseEvent(type, {
				isTrusted: true,
				clientX: clientX,
				clientY: clientY,
				bubbles: true,
				cancelable: true,
				view: window

			});
			return evt;
		}
		function _Pointer(type, clientX, clientY){
			let evt = new PointerEvent(type, {
				isTrusted: true,
				clientX: clientX,
				clientY: clientY,
				bubbles: true,
				cancelable: true,
				view: window

			});
			return evt;
		}
		var canvas_icons = document.querySelector('canvas') || document.querySelector('img.captcha-image') || document.querySelector('.captcha-show img') || document.querySelector('#rscaptcha_img');
		var offset = getOffset(canvas_icons);
		canvas_icons.focus();
		var x = + Number(answer.split(':')[0]) + offset.left,
		y = + Number(answer.split(':')[1]) + offset.top;
		canvas_icons.dispatchEvent(_Event("mousedown", x, y));
		canvas_icons.dispatchEvent(_Event("mouseup", x, y));
		canvas_icons.dispatchEvent(_Pointer("click", x, y));
    },
    getForm: function(widget){
        return false;
    },
    getCallback: function(widget){
        return null;
    },
});