﻿(() => {
    const ROOT_SELECTOR = '#pCaptcha';
    const CHECKBOX_SELECTOR = `${ROOT_SELECTOR} .captcha-checkbox`;
    const CHALLENGE_SELECTOR = `${ROOT_SELECTOR} .captcha-challenge`;
    const TASK_SELECTOR = `${ROOT_SELECTOR} .captcha-challenge-header`;
    const BODY_SELECTOR = `${ROOT_SELECTOR} .captcha-image-grid`;

    const isVisible = el => {
        if(!el){return false;}
        const rect = el.getBoundingClientRect();
        return !!(rect.width || rect.height || el.getClientRects().length);
    };

    const extractTask = () => {
        const taskNode = document.querySelector(TASK_SELECTOR);
        return taskNode ? taskNode.textContent.trim() : null;
    };

    const extractImageBase64 = async () => {
        const grid = document.querySelector(BODY_SELECTOR);
        if(!grid){return null;}
        const firstCell = grid.querySelector('.captcha-image-cell');
        if(!firstCell){return null;}
        const style = window.getComputedStyle(firstCell);
        const bgImage = style.backgroundImage;
        if(!bgImage || bgImage === 'none'){return null;}
        const match = bgImage.match(/url\(["']?(.*?)["']?\)/);
        if(!match || !match[1]){return null;}
        let url = match[1];
        try{
            url = new URL(url, location.href).href;
        }catch(e){}
        try{
            const response = await fetch(url, {credentials: 'omit'});
            if(!response.ok){return null;}
            const blob = await response.blob();
            return await blobToDataURL(blob);
        }catch(e){
            console.error(e);
            return null;
        }
    };

    const blobToDataURL = blob => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });

    const ensureCheckboxOpen = () => {
        const checkbox = document.querySelector(CHECKBOX_SELECTOR);
        const challenge = document.querySelector(CHALLENGE_SELECTOR);
        if(!checkbox){return;}
        if(isVisible(checkbox) && (!challenge || !isVisible(challenge))){
            checkbox.click();
        }
    };

    const registerWidgetIfReady = async () => {
        if(!window._mbRegisterCaptchaWidget){return;}

        const container = document.querySelector(ROOT_SELECTOR);
        if(!container){return;}
        if(!container.id){
            container.id = `pcaptcha-container-${Date.now()}`;
        }

        const task = extractTask();
        if(!task){return;}

        const errorMessage = container.querySelector('[id^="error-message-"]:not([style*="display: none"])');
        if(errorMessage && errorMessage.textContent.trim().length){
            const refreshBtn = container.querySelector('[id*="refresh-btn-"]');
            if(refreshBtn){
                refreshBtn.click();
            }
            return;
        }

        const body = await extractImageBase64();
        if(!body){return;}

        const prevBody = container.dataset.pcaptchaBody;
        const prevTask = container.dataset.pcaptchaTask;
        const hasChanged = prevBody && prevBody !== body || prevTask && prevTask !== task;

        if(hasChanged){
            try{ _mbDelCaptchaWidget(); }catch(e){ console.error(e); }
            try{
                const button = _mbGetCaptchaWidgetButton('pcaptcha', container.id);
                if(button){button.remove();}
            }catch(e){console.error(e);}
            container.removeAttribute('data-loaded');
        }

        if(!hasChanged && _mbIsCaptchaWidgetRegistered('pcaptcha', container.id)){return;}

        container.dataset.pcaptchaBody = body;
        container.dataset.pcaptchaTask = task;
		
        _mbRegisterCaptchaWidget({
            captchaType: 'pcaptcha',
            widgetId: container.id,
            containerId: container.id,
            task: task,
            body: body,
			callback: null,
        });
    };

    let busy = false;
    setInterval(async () => {
        if(busy){return;}
        busy = true;
        try{
            ensureCheckboxOpen();
            await registerWidgetIfReady();
        } finally {
            busy = false;
        }
    }, 2000);
})();