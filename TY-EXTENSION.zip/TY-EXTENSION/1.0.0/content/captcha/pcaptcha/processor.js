﻿CaptchaProcessors.register({
    captchaType: "pcaptcha",
    canBeProcessed: function(widget, config){
        if(!config.solvepCaptcha){return false;}
        if(!$(`#${widget.containerId}`).length){return false;}
        return true;
    },
    attachButton: function(widget, config, button){
        let container = $(`#${widget.containerId}`);
        button.css({
            width: container.find('iframe').outerWidth() + "px"
        });
		container.append(button);
        if(config.solvepCaptcha){
			button.click();
		}
    },
    getParams: function(widget, config){
        return {
            body: widget.body,
            task: widget.task
        };
    },
    onSolved: function(widget, answer){
        try{
            const container = document.querySelector(`#${widget.containerId}`) || document.querySelector('#pCaptcha');
            if(!container){return;}
            const grid = container.querySelector('.captcha-image-grid');
            if(!grid){return;}

            const size = this.getCellSize(grid);
            if(!size){return;}

            const coords = this.parseAnswer(answer);
			if(coords){
				coords.forEach(coord => {
					const index = this.coordinateToIndex(coord.x, coord.y, size);
					if(index === null){return;}
					const cell = grid.querySelector(`.captcha-image-cell[data-index="${index}"]`);
					if(cell){
						cell.click();
					}
				});

				const verifyBtn = container.querySelector('.captcha-verify-btn');
				if(verifyBtn){
					verifyBtn.click();
				}
			}
			else{
				const refreshBtn = container.querySelector('[id*="refresh-btn-"]');
				if(refreshBtn){
					refreshBtn.click();
				}
			}
        }catch(e){
            console.error(e);
        }
    },
    getCellSize(grid){
        const cell = grid.querySelector('.captcha-image-cell');
        if(!cell){return null;}
        const style = window.getComputedStyle(cell);
        const bgSize = style.backgroundSize;
        const match = bgSize && bgSize.match(/(\d+)px\s+(\d+)px/);
        if(!match){return null;}
        const totalWidth = parseInt(match[1], 10);
        const totalHeight = parseInt(match[2], 10);
        return {totalWidth, totalHeight};
    },
    parseAnswer(answer){
        if(!answer){return [];} 
        return answer.split(',').map(pair => {
            const [x,y] = pair.split(':').map(n => parseFloat(n.trim()));
            return {x, y};
        }).filter(coord => !isNaN(coord.x) && !isNaN(coord.y));
    },
    coordinateToIndex(x, y, size){
        if(!size){return null;}
        const cellWidth = size.totalWidth / 3;
        const cellHeight = size.totalHeight / 3;
        const col = Math.min(2, Math.max(0, Math.floor(x / cellWidth)));
        const row = Math.min(2, Math.max(0, Math.floor(y / cellHeight)));
        return row * 3 + col;
    },
    getForm: function(widget){
        return false;
    },
    getCallback: function(widget){
        return null;
    },
});

