﻿function waitForElementToDisappear(selector, timeout = 5000) {
    return new Promise((resolve) => {
        const element = document.querySelector(selector);
        if (!element) {
            resolve(true);
            return;
        }
        const observer = new MutationObserver((mutations) => {
            const element = document.querySelector(selector);
            if (!element) {
                observer.disconnect();
                resolve(true);
            }
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        setTimeout(() => {
            observer.disconnect();
            resolve(false);
        }, timeout);
    });
}

function isVisible(sel) {
    var e = document.querySelector(sel);
    return !!e && (e.offsetWidth || e.offsetHeight || e.getClientRects().length);
}

function isCanvasReady(canvas) {
    try {
        var context = canvas.getContext('2d', { willReadFrequently: true });
        var pixelBuffer = new Uint32Array(
            context.getImageData(0, 0, canvas.width, canvas.height).data.buffer
        );
        return pixelBuffer.some(color => color !== 0);
    } catch (e) {
        return false;
    }
}

function captureCanvasWithWhiteBackground(canvas) {
    // Создаем временный canvas
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    const tempContext = tempCanvas.getContext('2d');

    // Заливаем временный canvas белым цветом
    tempContext.fillStyle = 'white';
    tempContext.fillRect(0, 0, tempCanvas.width, tempCanvas.height);

    // Копируем содержимое оригинального canvas на временный
    tempContext.drawImage(canvas, 0, 0);

    // Возвращаем изображение с белым фоном
    return tempCanvas.toDataURL('image/png');
}


window.addEventListener('message', (event) => {

  // Проверяем структуру данных
  if (!event.data || !event.data.data) {
    return;
  }

  // Извлекаем данные
  const receivedData = event.data.data;

  // Пример использования данных

    if (receivedData.captcha) {
  
	//var container = document.querySelector('iframe[src*="https://iconcaptcha.one/challenge/render"]').parentNode;
	var container = document.querySelector('.icaptcha').parentNode;
	if(!container.id){
		container.id = "iconcaptcha-container-" + Date.now();
	}
    _mbRegisterCaptchaWidget({
		captchaType: "iconcaptcha",
		widgetId: 0,
		body: receivedData.captcha,
		captchaId: receivedData.id,
		containerId: container.id,
		callback: null,
	});
  }
});


(() => {
    timer = setInterval(async function () {
        if (window._mbRegisterCaptchaWidget) {
            if (!_mbIsCaptchaWidgetRegistered("iconcaptcha", 0)) {
                var body = false;
                if (isVisible('.iconcaptcha-modal__body')) {
                    const widget = document.querySelector(".iconcaptcha-widget");
                    if (widget) {
                        widget.classList.replace("iconcaptcha-theme-dark", "iconcaptcha-theme-light");
                        if (widget.dataset.theme === "dark") {
                            widget.dataset.theme = "light";
                        }
                    }
                    document.querySelector('.iconcaptcha-modal__body').click();
                    await new Promise(resolve => setTimeout(resolve, 500));
                    await waitForElementToDisappear('.captcha-loader');
                }
                if (isVisible('.iconcaptcha-modal__body canvas')) {
                    const canvas = document.querySelector(".iconcaptcha-modal__body canvas");
                    if (isCanvasReady(canvas)) {
                        // Используем функцию для создания скриншота с белым фоном
                        //body = captureCanvasWithWhiteBackground(canvas);
                        body = canvas.toDataURL('image/png').replace(/^data:image\/png;base64,/, '');
                    }
                }
                if (location.host == "iconcaptcha.one") {
                    try {
						clearInterval(timer);
                        const response = await fetch("https://iconcaptcha.one/challenge/request", {
                            method: "POST",
							referrer: "https://iconcaptcha.one/challenge/render?theme=light",
                            body: JSON.stringify({ theme: "light" }),
                        });
                        const send_data= await response.json();
						window.parent.postMessage(
						{data:send_data},
						  '*'
						);
                    } catch (e) {console.error("Fetch error:", e)}
                }
                if (body) {
                    var container = document.querySelector(".iconcaptcha-widget").parentNode;
                    container.id = "iconcaptcha-container-" + Date.now();
                    _mbRegisterCaptchaWidget({
                        captchaType: "iconcaptcha",
                        widgetId: 0,
                        body: body,
                        containerId: container.id,
                        callback: null,
                    });
                }
            }
        }
    }, 5000);
})();