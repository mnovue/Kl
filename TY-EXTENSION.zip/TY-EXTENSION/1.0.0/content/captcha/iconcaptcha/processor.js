﻿CaptchaProcessors.register({
    captchaType: "iconcaptcha",
    canBeProcessed: function(widget, config){
        if(!config.solveIconCaptcha){return false;}
        if(!$(`#${widget.containerId}`).length){return false;}
        return true;
    },
    attachButton: function(widget, config, button) {
        let container = $(`#${widget.containerId}`);
        button.css({
            width: container.find('iframe').outerWidth() + "px"
        });
		container.append(button);
        if(config.solveIconCaptcha){
			button.click();
		}
    },
    getParams: function(widget, config){
        return {
            body: widget.body
        };
    },
    onSolved: function(widget, answer){	
	
		function solveIcaptcha(answer) {
			const [x, y] = answer.split(':').map(Number);
			const percentX = Math.round((x / 300) * 100);
			const percentY = Math.round((y / 250) * 100);
			
			const base = {
				"id":widget.captchaId,
				"x":x,
				"y":y,
				"percentX":percentX,
				"percentY":percentY,
				"misc":{
					"isHeadless":false,
					"userAgent":navigator.userAgent,
					"hasWebGL":true,
					"screenResolution":{"width":screen.width,"height":screen.height},
					"colorDepth":screen.colorDepth,
					"logicalProcessors":navigator.hardwareConcurrency,
					"prefersReducedMotion":false
				}
			}
			const jsonString = JSON.stringify(base);
			const base64Encoded = btoa(unescape(encodeURIComponent(jsonString)));
			document.querySelector("#icaptcha-input").value = base64Encoded;
		}
		
		function waitForElement(selector, timeout = 5000) {
			return new Promise((resolve) => {
				const element = document.querySelector(selector);
				if (element) {
					resolve(element);
					return;
				}
				const observer = new MutationObserver((mutations) => {
					const element = document.querySelector(selector);
					if (element) {
						observer.disconnect();
						resolve(element);
					}
				});
				observer.observe(document.body, {
					childList: true,
					subtree: true
				});
				setTimeout(() => {
					observer.disconnect();
					resolve(null);
				}, timeout);
			});
		}
		function createMouseEvent(type, x, y, element, options = {}) {
			const rect = element.getBoundingClientRect();
			const event = new MouseEvent(type, {
				bubbles: true,
				cancelable: true,
				view: window,
				detail: 1,
				screenX: x + window.screenX,
				screenY: y + window.screenY,
				clientX: x,
				clientY: y,
				ctrlKey: false,
				altKey: false,
				shiftKey: false,
				metaKey: false,
				button: 0,
				buttons: type === 'mouseup' ? 0 : 1,
				relatedTarget: null,
				...options
			});
			Object.defineProperties(event, {
				offsetX: { get: () => x - rect.left },
				offsetY: { get: () => y - rect.top },
				pageX: { get: () => x + window.pageXOffset },
				pageY: { get: () => y + window.pageYOffset },
				which: { get: () => 1 }
			});
			return event;
		}
		function generateMousePath(startX, startY, endX, endY, steps = 10) {
			const points = [];
			for (let i = 0; i <= steps; i++) {
				const t = i / steps;
				const x = startX + (endX - startX) * t + Math.sin(t * Math.PI) * 2;
				const y = startY + (endY - startY) * t + Math.sin(t * Math.PI) * 2;
				points.push({ x: Math.round(x), y: Math.round(y) });
			}
			return points;
		}
		async function simulateRealisticMouseMove(element, startX, startY, endX, endY) {
			const points = generateMousePath(startX, startY, endX, endY, 15);
			const startEvent = createMouseEvent('mouseover', startX, startY, element);
			element.dispatchEvent(startEvent);
			await new Promise(resolve => setTimeout(resolve, 50));
			
			element.dispatchEvent(createMouseEvent('mouseenter', startX, startY, element));
			await new Promise(resolve => setTimeout(resolve, 50));
			for (const point of points) {
				element.dispatchEvent(createMouseEvent('mousemove', point.x, point.y, element));
				await new Promise(resolve => setTimeout(resolve, 20));
			}
		}
		async function startCaptchaSelection(coordinates) {
			const [targetX, targetY] = coordinates.split(':').map(Number);
			const selectionDiv = await waitForElement('.iconcaptcha-modal__body-selection');
			const indicator = await waitForElement('.iconcaptcha-modal__body-selection i');
			const rect = selectionDiv.getBoundingClientRect();
			const mouseX = Math.round(rect.left + targetX);
			const mouseY = Math.round(rect.top + targetY);
			await simulateRealisticMouseMove(selectionDiv, mouseX - 30, mouseY - 30, mouseX, mouseY);
			await new Promise(resolve => setTimeout(resolve, 200));
			await simulateRealisticMouseMove(indicator, mouseX, mouseY, mouseX, mouseY);
			indicator.dispatchEvent(createMouseEvent('mousedown', mouseX, mouseY, indicator));
			await new Promise(resolve => setTimeout(resolve, 100));
			indicator.dispatchEvent(createMouseEvent('mouseup', mouseX, mouseY, indicator));
			indicator.dispatchEvent(createMouseEvent('click', mouseX, mouseY, indicator));
		}
		
		if(widget?.captchaId){
			solveIcaptcha(answer);
		}
		else{
			window.startCaptchaSelection = startCaptchaSelection;
			startCaptchaSelection(answer);
		}
    },
    getForm: function(widget){
        return false;
    },
    getCallback: function(widget){
        return null;
    },
});