﻿Config.getAll().then(function(config){
	if(config.isPluginEnabled && config.email){
		let scripts = [
			["content/captcha/faucetpay/hunter.js", config.solveFaucetPay],
			["content/captcha/pcaptcha/hunter.js", config.solvepCaptcha],
			["content/captcha/upside/hunter.js", config.solveUpside],
			["content/captcha/turnstile/hunter.js", config.solveTurnstile],
			["content/captcha/captchafox/hunter.js", config.solveCaptchaFox],
			["content/captcha/iconcaptcha/hunter.js", config.solveIconCaptcha],
			["content/captcha/recaptcha/hunter.js", config.solveRecaptchaV2 || config.solveRecaptchaV3],
			["content/captcha/hcaptcha/hunter.js", config.solveHCaptcha && config.hcaptchaType == "token"],
			["content/communication_helpers.js", true],
			["content/captcha/captchafox/interceptor.js", config.solveCaptchaFox],
			["content/captcha/turnstile/interceptor.js", config.solveTurnstile],
			["content/captcha/recaptcha/interceptor.js", config.interceptorRecaptcha && (config.solveRecaptchaV2 || config.solveRecaptchaV3)],
			["content/captcha/hcaptcha/interceptor.js", config.solveHCaptcha && config.hcaptchaType == "token"],
			["content/core_helpers.js", true]
		];
		let isHostInList = false;
		if (config.hostsForClick && Array.isArray(config.hostsForClick)) {
			isHostInList = config.hostsForClick.some(host => location.host.includes(host));
		}
		
		if(config.solveHCaptcha && config.hcaptchaType == "click" && 
		   (location.host.includes(".hcaptcha.") || isHostInList)){
			scripts = [
				["content/captcha/hcaptchabase64/click.js", true]
			];
		}
		scripts.forEach(s => {
			if (s.length > 1 && !s[1]) return;
			let script = document.createElement('script');
			script.src = chrome.runtime.getURL(s[0]);
			script.onload = function() {
				this.remove();
			};
			(document.head||document.documentElement).prepend(script);
		});
	}
});
var CaptchaProcessors = {
    list: {},
    register: function(processor){
        this.list[processor.captchaType] = processor;
    },
    get: function(captchaType){
        return this.list[captchaType];
    },
};
let CAPTCHA_WIDGETS_LOOP = setInterval(function(){
    Config.getAll().then(config => {
        if(!config.isPluginEnabled){return;}
        if(config.apiKey === null){return;}
        $("head").find("captcha-widget").each(function(){
            let widget = $(this);
            let widgetInfo = prepareWidgetInfo(widget[0].dataset);
            if(widgetInfo.reset){
                getSolverButton(widgetInfo.captchaType, widgetInfo.widgetId).remove();
                widget.removeAttr("data-loaded");
                widget.removeAttr("data-reset");
            }
            if(widgetInfo.loaded){return;}
            if(nextcreateSolverButton(config,widgetInfo.captchaType)){
                let processor = CaptchaProcessors.get(widgetInfo.captchaType);
                if(processor.canBeProcessed(widgetInfo, config)){
                    let button = createSolverButton(widgetInfo.captchaType, widgetInfo.widgetId);
                    processor.attachButton(widgetInfo, config, button);
                    widget[0].dataset.loaded = true;
                }
            }
        });
    });
}, 2000);
var background = chrome.runtime.connect({name: "content"});

function safePostMessage(port, message) {
    try {
        if (port && !chrome.runtime.lastError) {
            port.postMessage(message);
            return true;
        }
    } catch (e) {
        console.log(e);
    }
    return false;
}

background.onMessage.addListener(function(msg){
    if(msg.action == "solve"){
        if(msg.request.messageId){
            return respondToWebPageMessage(msg);
        }
        let button = getSolverButton(msg.request.captchaType, msg.request.widgetId);
        if(msg.error === undefined){
            changeSolverButtonState(button,"solved", msg.request.captchaType, chrome.i18n.getMessage("solved"));
            doActionsOnSuccess(msg);
        } 
		else{
            changeSolverButtonState(button,"error", msg.request.captchaType, msg.error);
        }
    }
});

background.onDisconnect.addListener(function(port){
    clearInterval(CAPTCHA_WIDGETS_LOOP);
});
function clearHOnlySessionCookie(){
    document.cookie.replace(
      /(?<=^|;).+?(?=\=|;|$)/g,
      name => location.hostname
        .split(/\.(?=[^\.]+\.)/)
        .reduceRight((acc, val, i, arr) => i ? arr[i]='.'+val+acc : (arr[i]='', arr), '')
        .map(domain => document.cookie=`${name}=;max-age=0;path=/;domain=${domain}`)
    );
};

function nextcreateSolverButton(config,captchaType){
    let captcha_solver = $(".captcha-solver");
    for(let captcha of captcha_solver){
        if($(captcha).attr('data-captcha-type')==="antibot"){
            if(config.afterDecisionAntibot){
                if($(captcha).attr('data-state')!="solved"){
                    return false;
                }
            }
        }
        else if(config.oneCaptchaPerPage && !["slider", "icons"].includes($(captcha).attr('data-captcha-type'))){
            return false;
        }
    }
    return true;
}
function doActionsOnSuccess(msg){
    let widget = getWidgetInfo(msg.request.captchaType, msg.request.widgetId);
    let processor = CaptchaProcessors.get(msg.request.captchaType);
    processor.onSolved(widget, msg.response.code);
    Config.getAll().then(config => {
        let callback = processor.getCallback(widget);
        if(callback){
            let textarea = document.createElement('textarea');
            textarea.id = 'mb-callback-trigger';
            textarea.setAttribute('data-function', callback);
            textarea.value = msg.response.code;
            document.body.appendChild(textarea);
        }
        if(config.autoSubmitForms === true){
            if(processor.getForm(widget)){
                let timeout = parseInt(config.submitFormsDelay) * 1000;
                setTimeout(function () {
                    if(!executeAutoSubmitRule(config.autoSubmitRules)){
                        processor.getForm(widget).submit();
                    }
                }, timeout);
            }
        }
    });
}
function executeAutoSubmitRule(rules){
    for(let i = 0; i < rules.length; i++){
        let regExp = new RegExp(rules[i].url_pattern);
        if(regExp.test(location.href)){
            let textarea = document.createElement('textarea');
            textarea.id = 'mb-autosubmit-code';
            textarea.value = rules[i].code;
            document.body.appendChild(textarea);
            return true;
        }
    }
    return false;
}
function createSolverButton(captchaType, widgetId) {
    let type_captcha = (captchaType=='normal') ? 'Image' : captchaType[0].toUpperCase() + captchaType.slice(1);
    let button = $(`
        <div class="captcha-solver" data-state="ready" data-captcha-type="${captchaType}" data-widget-id="${widgetId}">
            <div class="captcha-solver-image">
                <img src="${chrome.runtime.getURL("assets/images/icon_32.png")}">
            </div>
            <div class="captcha-solver-info">${chrome.i18n.getMessage("solveWith2Captcha")} ${type_captcha}</div>
        </div>
    `);
    button.click(function(){
        if(!["ready", "error"].includes(button.attr("data-state"))){return;}
        if(button[0].dataset.countErrors && button[0].dataset.disposable){
            return changeSolverButtonState(button, "error", captchaType, "EXPIRED");
        }
        changeSolverButtonState(button, "solving", captchaType, chrome.i18n.getMessage("solving"));
        let widget = getWidgetInfo(captchaType, widgetId);
        Config.getAll().then(function(config){
            let params = CaptchaProcessors.get(captchaType).getParams(widget, config);
            safePostMessage(background, {
                action: "solve",
                captchaType: captchaType,
                widgetId: widgetId,
                params: params,
            });
        });
    });
    return button;
}
function changeSolverButtonState(button, state, captchaType, message){
    Config.getAll().then(config => {
        let type_captcha = (captchaType=='normal') ? 'Image' : captchaType[0].toUpperCase() + captchaType.slice(1);
        button.attr("data-state", state)
        button.find(".captcha-solver-info").text(`${type_captcha} ${message}`);
        if(state === "error"){
            button[0].dataset.countErrors = parseInt(button[0].dataset.countErrors || 0) + 1;
            button.find(".captcha-solver-image img").attr("src",chrome.runtime.getURL("assets/images/wrong.png"));
            if(config.refreshPage){
                if(config.deleteCoockie){
                    clearHOnlySessionCookie();
                }
                location.reload();
            }
        }
        else if(state === "solving"){
            button.find(".captcha-solver-image img").attr("src",chrome.runtime.getURL("assets/images/gears.gif"));
        }
        else if(state === "solved"){
            button.find(".captcha-solver-image img").attr("src",chrome.runtime.getURL("assets/images/success.png"));
        }
    });
}
function getSolverButton(captchaType, widgetId){
    return $(`.captcha-solver[data-captcha-type="${captchaType}"][data-widget-id="${widgetId}"]`);
}
function getWidgetInfo(captchaType, widgetId){
    let widget = $("head").find(`captcha-widget[data-captcha-type="${captchaType}"][data-widget-id="${widgetId}"]`);
    if (!widget.length) return null;
    return prepareWidgetInfo(widget[0].dataset);
}
function prepareWidgetInfo(dataset){
    let w = {};
    for(let k in dataset){
        w[k] = dataset[k];
        if(w[k] === "null"){w[k] = null;}
		if(w[k] === "false"){w[k] = false;}
		if(w[k] === "true") {w[k] = true;}
    }
    return w;
}
let webPageMsgInterval = setInterval(function(){
    $("body > solver-ext-messages").children().each(function(){
        let msg = $(this)[0];
        if(!msg.dataset.received){
            msg.dataset.received = true;
            if(msg.dataset.action === "getConfig"){
                Config.getAll().then(config => {
                    setWebPageMessageResponse(msg, config);
                }).catch(e => {
                    setWebPageMessageResponse(msg, {error: e});
                });
            } 
			else if(msg.dataset.action === "solve"){
                let data = JSON.parse(decodeURIComponent(msg.dataset.data));
                safePostMessage(background, {
                    action: "solve",
                    captchaType: data.captchaType,
                    widgetId: data.widgetId,
                    params: data.params,
                    messageId: msg.dataset.messageId,
                });
            } 
			else{
                setWebPageMessageResponse(msg, {error: "unknown_action"});
            }
        }
    });
}, 200);
function respondToWebPageMessage(msg){
    let message = $(`body > solver-ext-messages > solver-ext-message[data-message-id="${msg.request.messageId}"]`);
    if(!message.length){return;}
    if(msg.error){
        setWebPageMessageResponse(message[0], {error: msg.error});
    } 
	else{
        setWebPageMessageResponse(message[0], {response: msg.response.code});
    }
}
function setWebPageMessageResponse(message, response){
    message.dataset.response = encodeURIComponent(JSON.stringify(response));
}
let contextMenuEl = null;
document.addEventListener("contextmenu", function(event){
    contextMenuEl = event.target;
}, true);
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
    if(request.command == "getContextMenuEl"){
        sendResponse({xpath: getXPath(contextMenuEl)});
        if(request.element == 'input'){
            $('.mb-toast .close').click();
        } 
		else if(request.showManual){
            showToast(chrome.i18n.getMessage("normalManual"));
        }
    }
});
function showToast(message){
    if(!$('body > .mb-toast-container').length){
        $('body').append(`<div class="mb-toast-container"></div>`);
    }
    let toastEl = $(`
        <div class="mb-toast">
            <img src="${chrome.runtime.getURL("assets/images/logo.svg")}" class="mb-toast-logo">
            <button type="button" class="close">&times;</button>
            <div class="mb-toast-message">${message}</div>
        </div>
    `).appendTo('.mb-toast-container');
    setTimeout(function (){
        toastEl.addClass('visible');
    }, 50);
    toastEl.find('button.close').click(function(e){
        toastEl.removeClass('visible');
        setTimeout(function(){
            toastEl.remove();
        }, 300);
    });
}
function getXPath(node){
    var comp, comps = [];
    var parent = null;
    var xpath = '';
    var getPos = function(node){
        var position = 1, curNode;
        if(node.nodeType == Node.ATTRIBUTE_NODE){
            return null;
        }
        for(curNode = node.previousSibling; curNode; curNode = curNode.previousSibling){
            if(curNode.nodeName == node.nodeName){
                ++position;
            }
        }
        return position;
    }
    if(node instanceof Document){
        return '/';
    }
    for(; node && !(node instanceof Document); node = node.nodeType == Node.ATTRIBUTE_NODE ? node.ownerElement : node.parentNode){
        comp = comps[comps.length] = {};
        switch (node.nodeType){
            case Node.TEXT_NODE:
                comp.name = 'text()';
                break;
            case Node.ATTRIBUTE_NODE:
                comp.name = '@' + node.nodeName;
                break;
            case Node.PROCESSING_INSTRUCTION_NODE:
                comp.name = 'processing-instruction()';
                break;
            case Node.COMMENT_NODE:
                comp.name = 'comment()';
                break;
            case Node.ELEMENT_NODE:
                comp.name = node.nodeName;
                break;
        }
        comp.position = getPos(node);
    }
    for(var i = comps.length - 1; i >= 0; i--){
        comp = comps[i];
        xpath += '/' + comp.name;
        if(comp.position != null){
            xpath += `[${comp.position}]`;
        }
    }
    return xpath;
}