﻿try {
    importScripts(
        '/common/config.js',
        '/common/api.js',
        '/background/background.js',
        '/content/captcha/normal/background.js'
    );
} catch (error) {
    console.error('Service Worker script loading failed:', error);
}

setInterval(() => { 
    self.serviceWorker?.postMessage?.({ type: 'keepAlive' }); 
}, 20000);

const storageListener = (changes, area) => {
    if (area === 'local' && changes.config && Config?.invalidateCache) {
        Config.invalidateCache();
    }
};
chrome.storage.onChanged.addListener(storageListener);