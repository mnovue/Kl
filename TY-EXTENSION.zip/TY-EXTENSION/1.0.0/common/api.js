﻿class MultiBot {
    constructor(options){
        if(typeof options == "string"){
            options = {apiKey: options}
        }
        let defaultOptions = {
            apiKey: "89e07e338c8d4b251557482581a2e0ad",
            service: "",
			defaultTimeoutToken: 300,
            defaultTimeout: 30,
            pollingInterval: 5,
        }
        for(let key in defaultOptions){
            this[key] = options[key] === undefined ? defaultOptions[key] : options[key];
        }
        
        Config.getAll().then(config => {
            if (config.defaultTimeoutToken) {
                this.defaultTimeoutToken = config.defaultTimeoutToken;
				this.defaultTimeout = config.defaultTimeout;
            }
        });
    }
    normal(captcha){
        captcha.method = "universal";
        return this.solve(captcha, {timeout: this.defaultTimeout});
    }
    recaptcha(captcha){
        captcha.method = "userrecaptcha";
        return this.solve(captcha, {timeout: this.defaultTimeoutToken});
    }
    hcaptcha(captcha){
        captcha.method = 'hcaptcha';
        return this.solve(captcha, {timeout: this.defaultTimeoutToken});
    }
    turnstile(captcha){
        captcha.method = 'turnstile';
        return this.solve(captcha, {timeout: this.defaultTimeoutToken});
    }
    captchafox(captcha){
        captcha.method = 'captchafox';
        return this.solve(captcha, {timeout: this.defaultTimeoutToken});
    }
    antibot(captcha){
        captcha.method = 'antibot';
        return this.solve(captcha, {timeout: this.defaultTimeout});
    }
    slider(captcha){
        captcha.method = 'slider';
        return this.solve(captcha, {timeout: this.defaultTimeout});
    }
    pcaptcha(captcha){
        captcha.method = 'cls';
        return this.solve(captcha, {timeout: this.defaultTimeout});
    }
    icons(captcha){
        captcha.method = 'icons';
        return this.solve(captcha, {timeout: this.defaultTimeout});
    }
    upside(captcha){
        captcha.method = 'upside';
        return this.solve(captcha, {timeout: this.defaultTimeout});
    }
    iconcaptcha(captcha){
        captcha.method = 'rscaptcha';
        return this.solve(captcha, {timeout: this.defaultTimeout});
    }
    async solve(captcha, waitOptions){
        let result = {};
        result.captchaId = await this.send(captcha);
        result.code = await this.waitForResult(result.captchaId, waitOptions);
        return result;
    }
    async send(captcha){
        let files = this.extractFiles(captcha);
        this.mapParams(captcha, captcha.method);
        this.mapParams(files, captcha.method);
        return await this.in(captcha, files);
    }
    async waitForResult(id, waitOptions){
		
        let startedAt = this.getTime();
        let timeout = waitOptions.timeout;
        let pollingInterval = this.pollingInterval;
        while(true){
            if(this.getTime() - startedAt < timeout){
                await new Promise(resolve => setTimeout(resolve, pollingInterval * 1000));
            } 
			else{
                break;
            }
            try{
                let code = await this.getResult(id);
                if(code){return code;}
            }catch (e){throw e;}
        }
        throw new Error(`Timeout ${timeout} seconds reached`);
    }
    
	getTime(){
        return parseInt(Date.now() / 1000);
    }
    
	async getResult(id){
        try{
            return await this.res({
                action: "get",
                id: id,
            });
        }catch(e){
			if(e.message == "CAPCHA_NOT_READY"){
                return null;
            }
            throw e;
        }
    }
    
	async userInfo(){
        return await this.res({action: "userinfo"});
    }
	
    extractFiles(captcha){
        let files = {};
        let fileKeys = ['file', 'hintImg'];
        for(let i = 1; i < 10; i++){
            fileKeys.push('file_' + i);
        }
        fileKeys.forEach(function(key){
            if(captcha[key] !== undefined){
                files[key] = captcha[key];
                delete captcha[key];
            }
        });
        return files;
    }
    
	mapParams(params, method){
        let map = this.getParamsMap(method);
        for(let k in map){
            let newName = k;
            let oldName = map[k];
            if(params[newName] !== undefined){
                params[oldName] = params[newName];
                delete params[newName];
            }
        }
    }
    
	getParamsMap(method){
        let commonMap = {
            base64: "body",
            url: "pageurl"
        };
        let methodMap = {
            userrecaptcha: {
                sitekey: "googlekey",
            }
        };
        if(methodMap[method] !== undefined){
            for(let key in methodMap[method]){
                commonMap[key] = methodMap[method][key];
            }
        }
        return commonMap;
    }
    
	async in(captcha, files){
        return await this.request('POST', '/in.php', captcha, files);
    }
    
	async res(data){
        return await this.request('GET', '/res.php', data);
    }
    
	async request(method, path, data, files){
        data.key = this.apiKey;
        data.json = 1;
        let url = "https://" + this.service + path;
        let options = {
            method: method,
        };
        if(method === 'GET'){
            let kv = [];
            for(let key in data){
                kv.push(key + '=' + encodeURIComponent(data[key]));
            }
            url += '?' + kv.join('&');
        }
        else if(data.method === 'GET'){
            let kv = [];
            for(let key in data){
                kv.push(key + '=' + encodeURIComponent(data[key]));
            }
            url += '?' + kv.join('&');
        }
        else{
            let formData = new FormData();
            for(let key in data){
                if(typeof data[key] == 'object'){
                    for(let ok in data[key]){
                        formData.append(key + "["+ok+"]", data[key][ok]);
                    }
                } 
				else{
                    formData.append(key, data[key]);
                }
            }
            options.body = formData;
        }
        let response;
        try{
            response = await fetch(url, options);
        }catch(e){throw new Error("API_CONNECTION_ERROR");}
        if(!response.ok){
			throw new Error(`API_HTTP_CODE_${response.status}`);
        }
        let json;
        try{
            json = await response.json();
        }catch(e){throw new Error("API_INCORRECT_RESPONSE");}
        if(json.status === 0){
            throw new Error(json.request);
        }
        return json.request || json;
    }
}