﻿var Config = {
    default: {
        isPluginEnabled: true,
        apiKey: null,
        email: null,
        autoSubmitForms: false,
        submitFormsDelay: 3,
        hcaptchabase64Attempts: 30,
        hcaptchaType: "token",
        afterDecisionAntibot: true,
        refreshPage: true,
        deleteCoockie: false,
        oneCaptchaPerPage: true,
		interceptorRecaptcha: false,
        solveNormal: false,
        solveRecaptchaV2: false,
        solveRecaptchaV3: false,
        solveHCaptcha: false,
        solveAntiBot: false,
        solveFaucetPay: false,
        solveUpside: false,
        solveTurnstile: false,
        solveCaptchaFox: false,
        solvepCaptcha: false,
        solveIconCaptcha: false,
        normalSources: [],
        autoSubmitRules: [],
        hostsForClick: ["store.steampowered.com", "www.epicgames.com"],
        humanMove: false,
        visualMove: false,
        defaultTimeoutToken: 300,
		defaultTimeout: 30
    },

    _cache: null,
    _cacheValid: false,

    get: async function(key) {
        const config = await this.getAll();
        return config[key];
    },

    getAll: function() {
        if (this._cacheValid && this._cache !== null) {
            return Promise.resolve(this._cache);
        }

        return new Promise((resolve, reject) => {
            chrome.storage.local.get('config', (result) => {
                const mergedConfig = this.joinObjects(this.default, result.config || {});
                this._cache = mergedConfig;
                this._cacheValid = true;
                resolve(mergedConfig);
            });
        });
    },

    set: function(newData) {
        return new Promise((resolve, reject) => {
            this.getAll()
                .then(data => {
                    const updatedConfig = this.joinObjects(data, newData);
                    chrome.storage.local.set({ config: updatedConfig }, () => {
                        this._cache = updatedConfig;
                        this._cacheValid = true;
                        resolve(updatedConfig);
                    });
                });
        });
    },

    joinObjects: function(obj1, obj2) {
        return { ...obj1, ...obj2 };
    },

    invalidateCache: function() {
        this._cacheValid = false;
        this._cache = null;
    }
};