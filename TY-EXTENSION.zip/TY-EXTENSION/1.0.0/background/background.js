﻿chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == 'install'){
        if(chrome.runtime.openOptionsPage){
            chrome.runtime.openOptionsPage();
        } 
		else{
            self.open(chrome.runtime.getURL('options/options.html'));
        }
    }
});
var API;
Config.getAll().then(config => {
    if(config.apiKey){
        initApiClient(config.apiKey);
    }
});
function initApiClient(apiKey){
    API = new MultiBot({
        apiKey: apiKey,
        service: "api.tertuyul.my.id",
		defaultTimeoutToken: 300,
        defaultTimeout: 30,
        pollingInterval: 5
    });
}
chrome.runtime.onConnect.addListener(function(port){
    port.onMessage.addListener(function(msg){
        let messageHandler = `${port.name}_${msg.action}`;
        if(self[messageHandler] === undefined){return;}
        self[messageHandler](msg)
            .then((response) => {
                port.postMessage({action: msg.action, request: msg, response});
            })
            .catch(error => {
				port.postMessage({action: msg.action, request: msg, error: error.message});
			});
    });
});
async function popup_login(msg){
    initApiClient(msg.apiKey);
    let info = await API.userInfo();
    Config.set({
        apiKey: msg.apiKey,
        email:  info.email,
    });
    return info;
}
async function popup_logout(msg){
    Config.set({apiKey: null});
    return {};
}
async function popup_getAccountInfo(msg){
    let config = await Config.getAll();
    if(!config.apiKey){
		throw new Error("No apiKey");
	}
    let info = await API.userInfo();
    return info;
}
async function content_solve(msg){
    return await API[msg.captchaType](msg.params);
}